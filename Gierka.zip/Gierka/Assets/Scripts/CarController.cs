﻿using UnityEngine;

public class CarController : MonoBehaviour
{
    [SerializeField] private float speed = 5f;
    private float leftBoundary;
    private float rightBoundary;
    private bool movingRight;
    private BoxCollider carCollider;

    public void Initialize(float carSpeed, bool moveRight, float leftPoint, float rightPoint)
    {
        speed = carSpeed;
        movingRight = moveRight;
        leftBoundary = leftPoint;
        rightBoundary = rightPoint;
        
        transform.rotation = Quaternion.Euler(0, movingRight ? 90 : -90, 0);
        
        // Dodajemy i konfigurujemy collider
        carCollider = gameObject.AddComponent<BoxCollider>();
        carCollider.isTrigger = true;
        carCollider.size = new Vector3(1f, 1f, 2f); // Dostosuj rozmiar do modelu samochodu
        carCollider.center = new Vector3(0f, 0.5f, 0f); // Wycentruj collider
        
        // Ustawiamy tag
        gameObject.tag = "Car";
        
        // Upewniamy się, że samochód ma odpowiednią warstwę
        gameObject.layer = LayerMask.NameToLayer("Default");
    }

    void Update()
    {
        float movement = speed * Time.deltaTime;
        transform.Translate(Vector3.forward * movement);

        if (movingRight && transform.position.x > rightBoundary)
        {
            Vector3 newPosition = transform.position;
            newPosition.x = leftBoundary;
            transform.position = newPosition;
        }
        else if (!movingRight && transform.position.x < leftBoundary)
        {
            Vector3 newPosition = transform.position;
            newPosition.x = rightBoundary;
            transform.position = newPosition;
        }
    }
}