﻿using UnityEngine;

public class LogController : MonoBehaviour
{
    private float speed;
    private float leftBoundary;
    private float rightBoundary;
    private bool movingRight;
    private bool hasPlayerOnTop = false;
    private Transform attachedPlayer;

    public void Initialize(float logSpeed, bool moveRight, float leftPoint, float rightPoint)
{
    speed = logSpeed;
    movingRight = moveRight;
    leftBoundary = leftPoint;
    rightBoundary = rightPoint;

    BoxCollider logCollider = gameObject.AddComponent<BoxCollider>();
    logCollider.isTrigger = true;
    logCollider.size = new Vector3(2f, 0.3f, 0.5f);
    // Obniżamy pozycję collidera kłody, aby lepiej pasowała do gracza
    logCollider.center = new Vector3(0f, 0.1f, 0f);

    transform.rotation = Quaternion.Euler(0, movingRight ? 90 : -90, 0);
    gameObject.tag = "Log";
}

void Update()
{
    float movement = speed * Time.deltaTime;
    Vector3 moveDirection = movingRight ? Vector3.right : Vector3.left;
    transform.Translate(moveDirection * movement);

    if (hasPlayerOnTop && attachedPlayer != null)
    {
        // Używamy MovePosition zamiast Translate dla bardziej stabilnego ruchu
        attachedPlayer.position += moveDirection * movement;
    }

    // Sprawdzamy granice i usuwamy kłodę
    if ((movingRight && transform.position.x > rightBoundary) ||
        (!movingRight && transform.position.x < leftBoundary))
    {
        if (hasPlayerOnTop && attachedPlayer != null)
        {
            // Upewniamy się, że gracz nie zostanie "zabrany" z kłodą
            hasPlayerOnTop = false;
            attachedPlayer = null;
        }
        Destroy(gameObject);
    }
}

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            hasPlayerOnTop = true;
            attachedPlayer = other.transform;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            hasPlayerOnTop = false;
            attachedPlayer = null;
        }
    }
}