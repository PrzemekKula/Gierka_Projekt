﻿using UnityEngine;

public class ParticleManager : MonoBehaviour
{
    [Header("Particle Systems")]
    [SerializeField] private ParticleSystem jumpParticles;
    [SerializeField] private ParticleSystem collisionParticles;
    
    private static ParticleManager instance;
    
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }
    
    public static void PlayJumpEffect(Vector3 position)
    {
        if (instance != null && instance.jumpParticles != null)
        {
            instance.jumpParticles.transform.position = position;
            instance.jumpParticles.Play();
        }
    }
    
    public static void PlayCollisionEffect(Vector3 position)
    {
        if (instance != null && instance.collisionParticles != null)
        {
            instance.collisionParticles.transform.position = position;
            instance.collisionParticles.Play();
        }
    }
}