using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using System.Collections;


public class PlayerController : MonoBehaviour
{
    [Header("Movement Settings")]
    [SerializeField] private float moveDistance = 1f;
    [SerializeField] private float moveDuration = 0.2f;

    [Header("Jump Settings")]
    [SerializeField] private float jumpForce = 8f;  
    [SerializeField] private float gravity = 20f;   
    private float verticalVelocity = 0f;

    [Header("UI Elements")]
    [SerializeField] private Button resetButton;

    private bool isMoving = false;
    private bool isJumping = false;
    private Vector3 targetPosition;
    private float moveProgress;
    private Vector3 startPosition;
    private float startHeight;
    private BoxCollider playerCollider;
    private LayerMask obstacleLayer;
    private bool isGameOver = false;
    private bool isOnLog = false;
    private Transform currentLog;
    private Animator leftWingAnimator;
    private Animator rightWingAnimator;

    void Start()
    {
        playerCollider = GetComponent<BoxCollider>();
        if (playerCollider == null)
        {
            playerCollider = gameObject.AddComponent<BoxCollider>();
        }
        playerCollider.size = new Vector3(0.8f, 1f, 0.8f);
        playerCollider.center = new Vector3(0f, 0.5f, 0f);

        obstacleLayer = LayerMask.GetMask("Obstacle");
        gameObject.tag = "Player";

        if (resetButton != null)
        {
            resetButton.onClick.AddListener(RestartGame);
        }

        startHeight = transform.position.y;

        // Pobieranie animatorów skrzydeł (obsługa błędów)
        leftWingAnimator = GameObject.Find("LeftWing")?.GetComponent<Animator>();
        rightWingAnimator = GameObject.Find("RightWing")?.GetComponent<Animator>();

        if (leftWingAnimator == null || rightWingAnimator == null)
        {
            Debug.LogError("Brak Animatora na skrzydłach! Upewnij się, że `LeftWing` i `RightWing` mają `Animator` przypisany w Inspectorze.");
        }
    }

    void Update()
    {
        if (isGameOver)
        {
            if (Input.GetKeyDown(KeyCode.R))
            {
                RestartGame();
            }
            return;
        }

        // Obsługa fizyki skoku
        UpdateJumpPhysics();

        if (!isMoving)
        {
            HandleInput();
        }
        else
        {
            UpdateMovement();
        }

        CheckWaterCollision();
    }

    private void HandleInput()
    {
        // Obsługa skoku
        if (Input.GetKeyDown(KeyCode.Space) && !isJumping)
        {
            StartJump();
        }

        // Obsługa ruchu
        Vector3? moveDirection = null;

        if (Input.GetKeyDown(KeyCode.W)) moveDirection = Vector3.forward;
        else if (Input.GetKeyDown(KeyCode.S)) moveDirection = Vector3.back;
        else if (Input.GetKeyDown(KeyCode.A)) moveDirection = Vector3.left;
        else if (Input.GetKeyDown(KeyCode.D)) moveDirection = Vector3.right;

        if (moveDirection.HasValue && CanMove(moveDirection.Value))
        {
            StartMove(moveDirection.Value);
        }
    }

    private IEnumerator ResetFlapTrigger()
    {
        yield return new WaitForSeconds(0.3f); // Czas trwania animacji
        leftWingAnimator.ResetTrigger("Flap");
        rightWingAnimator.ResetTrigger("Flap");
        Debug.Log("Flap Trigger został zresetowany!");
    }


    private void StartJump()
    {
        isJumping = true;
        verticalVelocity = jumpForce;

        // Odtwórz efekt skoku
        ParticleManager.PlayJumpEffect(transform.position);
        // Uruchomienie animacji skrzydeł
        if (leftWingAnimator != null && rightWingAnimator != null)
        {
            leftWingAnimator.Rebind();
            rightWingAnimator.Rebind();
            leftWingAnimator.SetTrigger("Flap");
            rightWingAnimator.SetTrigger("Flap");
        }
    }

    private void UpdateJumpPhysics()
    {
        if (transform.position.y > startHeight || verticalVelocity > 0)
        {
            // Zastosowanie grawitacji
            verticalVelocity -= gravity * Time.deltaTime;

            // Aktualizacja pozycji
            Vector3 position = transform.position;
            position.y += verticalVelocity * Time.deltaTime;

            // Zapobieganie zapadaniu się w ziemię
            if (position.y < startHeight)
            {
                position.y = startHeight;
                verticalVelocity = 0;
                isJumping = false;
            }

            transform.position = position;
        }
        else
        {
            if (isJumping)
            {
                verticalVelocity = 0;
                isJumping = false;
                Vector3 position = transform.position;
                position.y = startHeight;
                transform.position = position;
            }
        }
    }

    private bool CanMove(Vector3 direction)
    {
        Vector3 rayStart = transform.position;
        RaycastHit hit;
        float rayDistance = moveDistance + 0.1f;

        Debug.DrawRay(rayStart, direction * rayDistance, Color.red, 0.1f);

        if (Physics.Raycast(rayStart, direction, out hit, rayDistance))
        {
            if (hit.collider.gameObject.layer == LayerMask.NameToLayer("Obstacle"))
            {
                return false;
            }
        }

        Vector3 targetPos = transform.position + (direction * moveDistance);
        if (Mathf.Abs(targetPos.x) > 4f)
        {
            return false;
        }

        return true;
    }

    private void UpdateMovement()
    {
        moveProgress += Time.deltaTime / moveDuration;
        if (moveProgress >= 1f)
        {
            transform.position = new Vector3(targetPosition.x, transform.position.y, targetPosition.z);
            isMoving = false;
        }
        else
        {
            Vector3 newPos = Vector3.Lerp(startPosition, targetPosition, moveProgress);
            newPos.y = transform.position.y;
            transform.position = newPos;
        }
    }

    private void StartMove(Vector3 direction)
    {
        isMoving = true;
        moveProgress = 0f;
        startPosition = transform.position;
        targetPosition = transform.position + (direction * moveDistance);
        transform.forward = direction;
    }

    private void CheckWaterCollision()
    {
        Vector3 checkPosition = transform.position - new Vector3(0f, 0.3f, 0f);

        Collider[] hitColliders = Physics.OverlapBox(
            checkPosition,
            new Vector3(0.4f, 0.2f, 0.4f),
            Quaternion.identity
        );

        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.CompareTag("Water") && !isOnLog)
            {
                GameOver();
                break;
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Water") && !isOnLog || other.CompareTag("Car"))
        {
            ParticleManager.PlayCollisionEffect(transform.position);
            GameOver();
        }
        else if (other.CompareTag("Log"))
        {
            isOnLog = true;
            currentLog = other.transform;
        }
        else if (other.CompareTag("Obstacle")) // 🚀 NOWA KOLIZJA Z DRZEWAMI I KAMIENIAMI
        {
            Debug.Log("Kurczak uderzył w przeszkodę!");
            isMoving = false; // Zatrzymanie ruchu po uderzeniu
        }
    }


    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Log"))
        {
            isOnLog = false;
            currentLog = null;
        }
    }

    private void GameOver()
    {
        if (!isGameOver)
        {
            isGameOver = true;
            Debug.Log("Game Over! Press R to restart.");
            FindObjectOfType<GameUI>().GameOver();
        }
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
