﻿using UnityEngine;
using System.Collections.Generic;

public enum TerrainType
{
    Grass,
    Road,
    Rock,
    TrainTrack,
    Tree,
    Water
}

[System.Serializable]
public class TerrainPrefabs
{
    public GameObject grassTile;
    public GameObject roadTile;
    public GameObject rockPrefab;
    public GameObject trainTrackTile;
    public GameObject treePrefab;
    public GameObject waterTile;
    public GameObject carPrefab;
    public GameObject logPrefab;
}

public class TerrainGenerator : MonoBehaviour
{
    [Header("Terrain Settings")]
    [SerializeField] private TerrainPrefabs prefabs;
    [SerializeField] private int initialTerrainCount = 15;
    [SerializeField] private float tileSize = 1f;
    [SerializeField] private int terrainWidth = 9;
    [SerializeField] private Transform player;
    
    [Header("Generation Settings")]
    [SerializeField] private float generateAheadDistance = 10f;
    [SerializeField] private float deleteTerrainDistance = -5f;
    [SerializeField] [Range(0f, 1f)] private float obstacleSpawnChance = 0.3f;

    [Header("Terrain Probabilities")]
    [SerializeField] [Range(0f, 1f)] private float grassProbability = 0.4f;
    [SerializeField] [Range(0f, 1f)] private float roadProbability = 0.3f;
    [SerializeField] [Range(0f, 1f)] private float waterProbability = 0.15f;
    [SerializeField] [Range(0f, 1f)] private float trainProbability = 0.15f;
    
    private List<GameObject> activeTerrainTiles = new List<GameObject>();
    private float nextGenerationZ = -1f;
    private float lastPlayerZ = 0f;
    private TerrainType lastTerrainType = TerrainType.Grass;

    private void Start()
    {
        if (player == null)
        {
            player = GameObject.FindGameObjectWithTag("Player").transform;
        }
        
        GenerateInitialTerrain();
    }

    private void Update()
    {
        if (player.position.z > lastPlayerZ)
        {
            CheckTerrainGeneration();
            CheckTerrainDeletion();
            lastPlayerZ = player.position.z;
        }
    }

    private void GenerateInitialTerrain()
    {
        // Generuj wodę na pozycji -1
        GenerateTerrainStrip(TerrainType.Water);
        
        // Generuj 4 bloki trawy zaczynając od pozycji 0
        for (int i = 0; i < 4; i++)
        {
            GenerateTerrainStrip(TerrainType.Grass);
        }
        
        // Generuj resztę terenu losowo
        for (int i = 0; i < initialTerrainCount - 5; i++)
        {
            GenerateNextTerrainStrip();
        }
    }

    private void GenerateNextTerrainStrip()
    {
        TerrainType terrainType = GetRandomTerrainType();
        GenerateTerrainStrip(terrainType);
    }

    private void GenerateTerrainStrip(TerrainType terrainType)
    {
        // Aktualizujemy ostatni typ terenu
        lastTerrainType = terrainType;
        
        GameObject parentObject = new GameObject($"TerrainStrip_{nextGenerationZ}");
        parentObject.transform.position = new Vector3(0, 0, nextGenerationZ);
        
        // Generuj podstawowy pas terenu
        for (int x = -terrainWidth/2; x <= terrainWidth/2; x++)
        {
            GameObject tilePrefab = GetPrefabForTerrainType(terrainType);
            Vector3 position = new Vector3(x * tileSize, 0, nextGenerationZ);
            GameObject tile = Instantiate(tilePrefab, position, Quaternion.identity, parentObject.transform);
            
            HandleTerrainSpecifics(terrainType, tile, position, parentObject, x);
        }
        
        // Dodaj RoadManager jeśli to droga
        if (terrainType == TerrainType.Road && prefabs.carPrefab != null)
        {
            RoadManager roadManager = parentObject.AddComponent<RoadManager>();
            roadManager.Setup(prefabs.carPrefab, terrainWidth);
        }
        
        activeTerrainTiles.Add(parentObject);
        nextGenerationZ += tileSize;
    }

    private void HandleTerrainSpecifics(TerrainType terrainType, GameObject tile, Vector3 position, GameObject parentObject, int x)
    {
        switch (terrainType)
        {
            case TerrainType.Water:
                SetupWaterTile(tile, parentObject, x);
                break;
            case TerrainType.Grass:
                SetupGrassTile(position, parentObject);
                break;
            default:
                if (terrainType != TerrainType.Road)
                {
                    AddDefaultCollider(tile);
                }
                break;
        }
    }

    private void SetupWaterTile(GameObject tile, GameObject parentObject, int x)
    {
        BoxCollider waterCollider = tile.AddComponent<BoxCollider>();
        waterCollider.isTrigger = true;
        waterCollider.size = new Vector3(1f, 0.2f, 1f);
        waterCollider.center = new Vector3(0f, 0.1f, 0f);
        tile.tag = "Water";
        
        // Dodaj system kłód do pierwszego kafelka w rzędzie
        if (x == -terrainWidth/2 && prefabs.logPrefab != null)
        {
            SetupLogManager(parentObject);
        }
    }

    private void SetupGrassTile(Vector3 position, GameObject parentObject)
    {
        // Najpierw dodaj kafelek trawy z colliderem
        GameObject grassTile = parentObject.transform.GetChild(parentObject.transform.childCount - 1).gameObject;
        grassTile.tag = "Grass"; // Dodajemy tag dla łatwiejszej identyfikacji
        AddDefaultCollider(grassTile);

        // Sprawdź czy możemy dodać przeszkodę
        if (CanPlaceObstacle(position) && Random.value < obstacleSpawnChance)
        {
            AddObstacle(position, parentObject.transform);
        }
    }

    private bool CanPlaceObstacle(Vector3 position)
    {
        // Sprawdź czy w pobliżu nie ma innych przeszkód
        Collider[] nearbyObjects = Physics.OverlapSphere(position, 1.0f);
        foreach (Collider col in nearbyObjects)
        {
            // Jeśli znaleziono cokolwiek innego niż trawa, nie umieszczaj przeszkody
            if (col.gameObject.layer == LayerMask.NameToLayer("Obstacle") ||
                col.CompareTag("Road") || col.CompareTag("Water") || 
                col.CompareTag("Car") || col.CompareTag("Log"))
            {
                return false;
            }
        }
        return true;
    }

    private void SetupLogManager(GameObject parentObject)
    {
        WaterLogManager logManager = parentObject.AddComponent<WaterLogManager>();
        bool movingRight = Random.value > 0.5f;
        float startX = transform.position.x - (terrainWidth / 2);
        float leftSpawnPoint = startX - 2f;
        float rightSpawnPoint = startX + terrainWidth + 2f;
        logManager.Initialize(prefabs.logPrefab, leftSpawnPoint, rightSpawnPoint, movingRight);
    }

    private void AddDefaultCollider(GameObject tile)
    {
        BoxCollider tileCollider = tile.AddComponent<BoxCollider>();
        tileCollider.isTrigger = false;
        tileCollider.size = new Vector3(1f, 0.1f, 1f);
        tileCollider.center = new Vector3(0f, -0.05f, 0f);
    }

private void AddObstacle(Vector3 position, Transform parent)
{
    if (!CanPlaceObstacle(position))
    {
        Debug.Log($"Próba wygenerowania przeszkody poza mapą: {position}");
        return;
    }

    Debug.Log($"Przeszkoda poprawnie wygenerowana: {position}");

    GameObject obstaclePrefab = Random.value > 0.5f ? prefabs.treePrefab : prefabs.rockPrefab;
    Vector3 obstaclePos = position + Vector3.up * 0.5f;
    Quaternion randomRotation = Quaternion.Euler(0, Random.Range(0, 360), 0);

    GameObject obstacle = Instantiate(obstaclePrefab, obstaclePos, randomRotation, parent);

    // Dodanie solidnej kolizji
    if (obstacle.GetComponent<Collider>() == null)
    {
        BoxCollider obstacleCollider = obstacle.AddComponent<BoxCollider>();
        obstacleCollider.size = new Vector3(0.8f, 1.5f, 0.8f);  // Dopasowanie rozmiaru
        obstacleCollider.center = new Vector3(0f, 0.75f, 0f);    // Ustawienie środka
    }

    // Ustawienie poprawnej warstwy i tagu
    obstacle.layer = LayerMask.NameToLayer("Obstacle");
    obstacle.tag = "Obstacle";
}


    private TerrainType GetRandomTerrainType()
    {
        // Jeśli poprzedni teren był wodą, nie generujemy kolejnej wody
        if (lastTerrainType == TerrainType.Water)
        {
            // Przeliczamy prawdopodobieństwa bez wody
            float totalWithoutWater = grassProbability + roadProbability + trainProbability;
            if (totalWithoutWater <= 0) return TerrainType.Grass;

            float normalizedGrass = grassProbability / totalWithoutWater;
            float normalizedRoad = roadProbability / totalWithoutWater;

            float random = Random.value;
            if (random < normalizedGrass)
                return TerrainType.Grass;
            else if (random < normalizedGrass + normalizedRoad)
                return TerrainType.Road;
            else
                return TerrainType.TrainTrack;
        }
        else
        {
            float totalProbability = grassProbability + roadProbability + waterProbability + trainProbability;
            if (totalProbability <= 0) return TerrainType.Grass;

            float normalizedGrass = grassProbability / totalProbability;
            float normalizedRoad = roadProbability / totalProbability;
            float normalizedWater = waterProbability / totalProbability;

            float random = Random.value;
            if (random < normalizedGrass)
                return TerrainType.Grass;
            else if (random < normalizedGrass + normalizedRoad)
                return TerrainType.Road;
            else if (random < normalizedGrass + normalizedRoad + normalizedWater)
                return TerrainType.Water;
            else
                return TerrainType.TrainTrack;
        }
    }

    private GameObject GetPrefabForTerrainType(TerrainType type)
    {
        switch (type)
        {
            case TerrainType.Grass:
                return prefabs.grassTile;
            case TerrainType.Road:
                return prefabs.roadTile;
            case TerrainType.Water:
                return prefabs.waterTile;
            case TerrainType.TrainTrack:
                return prefabs.trainTrackTile;
            default:
                return prefabs.grassTile;
        }
    }

    private void CheckTerrainGeneration()
    {
        while (nextGenerationZ < player.position.z + generateAheadDistance)
        {
            GenerateNextTerrainStrip();
        }
    }

    private void CheckTerrainDeletion()
    {
        for (int i = activeTerrainTiles.Count - 1; i >= 0; i--)
        {
            if (activeTerrainTiles[i].transform.position.z < player.position.z + deleteTerrainDistance)
            {
                GameObject terrainToDelete = activeTerrainTiles[i];
                activeTerrainTiles.RemoveAt(i);
                Destroy(terrainToDelete);
            }
        }
    }
}