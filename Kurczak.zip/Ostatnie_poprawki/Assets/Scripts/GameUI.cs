﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameUI : MonoBehaviour
{
    [Header("UI Elements")]
    [SerializeField] private Button startButton;
    [SerializeField] private Button exitButton;
    [SerializeField] private Button resetButton; // Nowy przycisk do resetowania gry
    [SerializeField] private Text gameTitle;
    [SerializeField] private GameObject player;
    [SerializeField] private Text distanceText;
    [SerializeField] private Text gameOverText;
    [SerializeField] private GameObject gameOverBackground;

    private Vector3 startPosition;
    private bool isGameRunning = false; // Flaga, czy gra jest uruchomiona

    private void Start()
    {
        startButton.onClick.AddListener(StartGame);
        exitButton.onClick.AddListener(ExitGame);

        if (resetButton != null)
            resetButton.onClick.AddListener(ResetGame);

        gameTitle.text = "Crossy Game"; // Tytuł gry
        player.SetActive(false); // Wyłączamy gracza na starcie
        startPosition = player.transform.position; // Zapisujemy startową pozycję gracza
        distanceText.text = "Distance: 0"; // Inicjalizacja tekstu odległości
        gameOverText.gameObject.SetActive(false); // Ukrywamy Game Over na starcie
        gameOverBackground.SetActive(false);
    }

    private void Update()
    {
        if (isGameRunning)
        {
            UpdateDistance();
        }
    }

    private void StartGame()
    {
        player.SetActive(true); // Aktywujemy gracza
        startPosition = player.transform.position; // Resetujemy startową pozycję gracza
        gameOverText.gameObject.SetActive(false); // Ukrywamy Game Over
        gameOverBackground.SetActive(false); // Ukrywamy tło Game Over
        distanceText.gameObject.SetActive(true); // Pokazujemy tekst dystansu
        isGameRunning = true; // Gra się rozpoczęła
    }

    private void ExitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false; // Zamyka grę w edytorze
#else
        Application.Quit(); // Zamyka grę w wersji zbudowanej
#endif
    }

    private void UpdateDistance()
    {
        if (player.activeSelf)
        {
            float distance = player.transform.position.z - startPosition.z;
            distanceText.text = "Distance: " + Mathf.FloorToInt(distance).ToString();
        }
    }

    public void GameOver()
    {
        gameOverText.gameObject.SetActive(true);
        gameOverBackground.SetActive(true);
        player.SetActive(false);
        isGameRunning = false; // Zatrzymujemy grę
    }

    private void ResetGame()
    {
        player.transform.position = startPosition; // Resetujemy pozycję gracza
        gameOverText.gameObject.SetActive(false); // Ukrywamy Game Over
        gameOverBackground.SetActive(false); // Ukrywamy tło Game Over
        distanceText.text = "Distance: 0"; // Resetujemy dystans
        isGameRunning = false; // Gra nie jest uruchomiona
        player.SetActive(false); // Wyłączamy gracza do momentu startu
    }
}
