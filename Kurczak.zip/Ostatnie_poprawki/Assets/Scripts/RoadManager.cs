﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoadManager : MonoBehaviour
{
    private GameObject carPrefab;
    private int roadWidth;
    
    [Header("Car Settings")]
    [SerializeField] private float minSpeed = 3f;
    [SerializeField] private float maxSpeed = 8f;
    [SerializeField] private int minCarsPerRoad = 1;
    [SerializeField] private int maxCarsPerRoad = 4;
    [SerializeField] private float carSpacing = 3f;
    private const float SPAWN_OFFSET = 5f; // Odległość spawnu od krawędzi planszy

    public void Setup(GameObject carPref, int width)
    {
        if (carPref == null)
        {
            Debug.LogError("Car Prefab is null in RoadManager!");
            return;
        }
        
        carPrefab = carPref;
        roadWidth = width;
        InitializeRoad();
    }

    private void InitializeRoad()
    {
        if (carPrefab == null) 
        {
            Debug.LogError("Trying to initialize road with null car prefab!");
            return;
        }

        float roadSpeed = Random.Range(minSpeed, maxSpeed);
        int carsCount = Random.Range(minCarsPerRoad, maxCarsPerRoad + 1);
        bool movingRight = Random.value > 0.5f;
        
        float startX = transform.position.x - (roadWidth / 2);
        float leftSpawnPoint = startX - SPAWN_OFFSET;
        float rightSpawnPoint = startX + roadWidth + SPAWN_OFFSET;
        
        for (int i = 0; i < carsCount; i++)
        {
            SpawnCar(roadSpeed, movingRight, leftSpawnPoint, rightSpawnPoint, i * carSpacing);
        }
    }

    private void SpawnCar(float speed, bool movingRight, float leftPoint, float rightPoint, float offset)
    {
        // Określamy punkt spawnu w zależności od kierunku ruchu
        float spawnX;
        if (movingRight)
        {
            spawnX = leftPoint - offset;  // Spawni się z lewej strony
        }
        else
        {
            spawnX = rightPoint + offset; // Spawni się z prawej strony
        }

        Vector3 spawnPosition = new Vector3(spawnX, 0.5f, transform.position.z);
        
        GameObject car = Instantiate(carPrefab, spawnPosition, Quaternion.identity, transform);
        CarController carController = car.AddComponent<CarController>();
        // Przekazujemy punkty graniczne zamiast pojedynczego startX
        carController.Initialize(speed, movingRight, leftPoint, rightPoint);
    }
}