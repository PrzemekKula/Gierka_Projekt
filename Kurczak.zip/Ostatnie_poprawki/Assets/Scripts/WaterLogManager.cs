﻿using UnityEngine;

public class WaterLogManager : MonoBehaviour
{
    [SerializeField] private float logSpeed = 2f;
    [SerializeField] private float spawnInterval = 3f;
    private float leftBoundary;
    private float rightBoundary;
    private GameObject logPrefab;
    private bool movingRight;

    public void Initialize(GameObject logPref, float leftPoint, float rightPoint, bool moveRight)
    {
        logPrefab = logPref;
        leftBoundary = leftPoint;
        rightBoundary = rightPoint;
        movingRight = moveRight;
        InvokeRepeating("SpawnLog", 0f, spawnInterval);
    }

    private void SpawnLog()
    {
        float spawnX = movingRight ? leftBoundary - 2f : rightBoundary + 2f;
        Vector3 spawnPosition = new Vector3(spawnX, 0.1f, transform.position.z);
        
        GameObject log = Instantiate(logPrefab, spawnPosition, Quaternion.identity, transform);
        LogController logController = log.AddComponent<LogController>();
        logController.Initialize(logSpeed, movingRight, leftBoundary, rightBoundary);
    }
}